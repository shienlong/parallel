#!/bin/bash

# stop namenode, datanode
stop-dfs.sh

# stop yarn manager
stop-yarn.sh