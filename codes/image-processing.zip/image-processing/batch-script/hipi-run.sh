#!/bin/bash

cd ../hipi

# gradle to compile hibImport tool
gradle clean tools:hibImport:jar

# hibImport convert images to hib format
tools/hibImport.sh ~/Desktop/TempImg tempimg.hib

cd examples/helloWorld

# initiate jar file
gradle jar

# implement with the mapreduce function in java
hadoop jar build/libs/helloWorld.jar tempimg.hib tempimg-average

# list the output files
hadoop fs -ls tempimg-average

# view the output
hadoop fs -cat tempimg-average/part-r-00000