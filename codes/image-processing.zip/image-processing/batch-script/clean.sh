#!/bin/bash

# remove the temporarily files
sudo rm -rf /opt/hadoop_tmp

# make new temp directory
sudo mkdir -p /opt/hadoop_tmp/hdfs/datanode

# give permission to temp file to execute certion priviledged command
sudo chown pi:hadoop -R /opt/hadoop_tmp/
sudo chmod 777 /opt/hadoop_tmp/hdfs/datanode