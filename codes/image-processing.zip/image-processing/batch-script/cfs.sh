#!/bin/bash

# remove the temporarily files
sudo rm -rf /opt/hadoop_tmp

# make new temp directory
sudo mkdir -p /opt/hadoop_tmp/hdfs/namenode

# give permission to temp file to execute certion priviledged command
sudo chown pi:hadoop -R /opt/hadoop_tmp/
sudo chmod 777 /opt/hadoop_tmp/hdfs/namenode

#format namenode
hdfs namenode -format

#starting daemons
start-dfs.sh
start-yarn.sh